function setup() {
    createCanvas(600, 400);
}

function draw() {
    background(0);
    circle(0, 0, 50);
}
let xBolinha = 300;
let yBolinha = 200;
let diametro = 15;
 let raio =diamrtro/2
function setup() {
    createCanvas(600, 400);
}

function draw() {
    background(0);
    circle(xBolinha, yBolinha, diametro);
}
//ybrolinha +velocidade ybrolinha
function draw() {
    background(0);
    circle(xBolinha - yBolinha, diametro);
    xBolinha = xBolinha + 1;
}
let ybolinha=300;

let velocidadeXBolinha = 2;
let velocidadeYBolinha = 2;

function setup() {
    createCanvas(600, 400);
}

function draw() {
    background(0);
    circle(xBolinha, yBolinha, diametro);
xBolinha += velocidadeXBolinha;
    yBolinha += velocidadeYBolinha;
}